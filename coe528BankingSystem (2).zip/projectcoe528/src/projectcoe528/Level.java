
package projectcoe528;

/**
 *
 * @author v2mathur
 */
public abstract class Level {

    public abstract void changeState(Account a);
    
    abstract void onlinePurchase(Account a,int cost);
    

}
